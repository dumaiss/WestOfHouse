# Implementation plan

M1 established the public API, V3 header foundation, bounded stack/frame storage, flat memory reads and dynamic writes, cooperative execution contract, SDK archive, test executable, and initial host fixtures.

M2 implements the bounded V3 decoder, variables and frames, core arithmetic/control flow, object links/attributes/properties, cooperative instruction execution, and a callback-backed logical-memory boundary. Host and target fixtures cover bytecode execution, state inspection, nested calls, stack-variable evaluation, property mutation, and a logical PC above 64 KiB. The callback API is ready for an application page mapper; an xmem-specific mapper and comprehensive whole-story opcode coverage remain outstanding.

M3 completes the remaining V3 instruction semantics needed for an interactive story. Add explicit output/input request events, then implement text services in M4. Compare execution against the unmodified `../../vendor/infocom-zork1/COMPILED/zork1.z3` at controlled checkpoints as opcode coverage grows. Keep implementation responsibilities in their existing source modules; do not consolidate into `zvm.c`.

M4 adds Z-text/ZSCII encoding, abbreviation expansion, dictionary/tokenization, host input/output integration, and save/restore request boundaries. M5 adds Quetzal interoperability, unchanged Zork I gameplay through the first prompt and beyond, profiling, and hardware validation. Each milestone requires deterministic fixtures plus target acceptance before claiming success.

The bounded stack/frame capacities remain provisional until measured against real story execution. The VM does not modify KonaOS or the West of House application.
