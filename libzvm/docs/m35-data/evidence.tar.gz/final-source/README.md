# libzvm

Z-machine V3 library for KonaOS, with an independent host-memory and I/O API.
The original Zork I story remains authoritative and unmodified.

```sh
make
make test
make test ZVM_PROFILE=1
```

The default build uses the sibling standalone KonaOS SDK. Its executable is
`build/cache-4-4/c-s512-fast/target/user/zvmtest.exe`. The test adapter keeps
four dynamic and four static pages, with a Z80 fast path for current-page
reads. `ZVM_CACHE_ASM=0` selects the C reference; `ZVM_PROFILE=1` enables
diagnostic counters. Variants have separate build directories.

The test app accepts `-p /fs/ZORK1.Z3` for keyboard play, `-a` for the original
seven-command script, `-b` for a ten-command benchmark, `-d` for discard
output, or `-B` for both benchmark sinks. KonaOS argv starts with the first
flag, without an executable-name argument.

See [M3.5 performance and acceptance](docs/m35-performance.md) for results,
resources, regression evidence and remaining limitations, and
[the cache assembly contract](docs/m35-cache-asm.md) for its private ABI.
The M1 architecture and M2/M3 semantics remain modular under `src/`.

Host cache tests reuse the sibling OS checkout's reader implementation;
override `KOS_READER_FULL_SOURCE` if that source is elsewhere. The production
target build needs only the exported SDK.
