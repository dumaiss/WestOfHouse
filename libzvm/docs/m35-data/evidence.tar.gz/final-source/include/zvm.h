#ifndef LIBZVM_ZVM_H
#define LIBZVM_ZVM_H

#include "kos/types.h"

#define ZVM_VERSION 3u
#define ZVM_STACK_CAPACITY 128u
#define ZVM_FRAME_CAPACITY 16u

typedef enum {
	ZVM_READY = 0, ZVM_NEED_INPUT, ZVM_NEED_SAVE, ZVM_NEED_RESTORE,
	ZVM_YIELDED, ZVM_FINISHED, ZVM_FAULT
} zvm_status_t;
typedef enum {
	ZVM_OK = 0, ZVM_EINVAL, ZVM_EVERSION, ZVM_EHEADER, ZVM_EBOUNDS,
	ZVM_EREADONLY, ZVM_ESTACK, ZVM_ESTATE, ZVM_EUNSUPPORTED,
	ZVM_EDIVZERO, ZVM_EFRAME
} zvm_error_t;
/* Fixed caller-owned storage keeps allocation explicit while hiding internals.
 * The pointer member supplies suitable alignment on both host and Z80 ABI. */
typedef union { void *_alignment; uint8_t _storage[1536]; } zvm_t;
typedef zvm_error_t (*zvm_memory_read_fn)(void *user, uint32_t address,
					 uint8_t *value);
typedef zvm_error_t (*zvm_memory_write_fn)(void *user, uint32_t address,
					  uint8_t value);
typedef zvm_error_t (*zvm_output_fn)(void *user, uint8_t channel, uint8_t byte);
typedef zvm_error_t (*zvm_status_fn)(void *user,uint16_t location,
				     uint16_t value1,uint16_t value2,
				     uint8_t time_mode);
enum { ZVM_OUTPUT_NARRATIVE = 0, ZVM_OUTPUT_STATUS = 1 };

/* The caller owns and keeps the writable story allocation alive. init validates
 * V3 header fields; reset restarts. release clears context and frees nothing. */
zvm_error_t zvm_init(zvm_t *vm, uint8_t *story, uint32_t story_size);
/* Alternative for banked/page-backed stories. The host owns backend and user
 * storage until release. Reads must cover [0, story_size); writes may reject. */
zvm_error_t zvm_init_memory(zvm_t *vm, zvm_memory_read_fn read_byte,
			    zvm_memory_write_fn write_byte, void *user,
			    uint32_t story_size);
zvm_error_t zvm_reset(zvm_t *vm);
void zvm_release(zvm_t *vm);
/* Output callback is synchronous; bytes are ASCII, CR becomes LF, and
 * unsupported extended ZSCII characters are represented by '?'. */
zvm_error_t zvm_set_output_callback(zvm_t *vm, zvm_output_fn callback,
				    void *user);
zvm_error_t zvm_set_status_callback(zvm_t *vm,zvm_status_fn callback,
				    void *user);
zvm_error_t zvm_seed_random(zvm_t *vm,uint16_t seed);
zvm_error_t zvm_set_story_checksum(zvm_t *vm,uint16_t checksum);

/* Executes at most budget instructions, preserving resumable VM state. */
zvm_status_t zvm_run(zvm_t *vm, uint16_t budget);
zvm_error_t zvm_submit_input(zvm_t *vm, const char *text);
zvm_status_t zvm_status(const zvm_t *vm);
zvm_error_t zvm_error(const zvm_t *vm);
uint32_t zvm_program_counter(const zvm_t *vm);
uint32_t zvm_fault_address(const zvm_t *vm);
uint8_t zvm_fault_opcode(const zvm_t *vm);
uint32_t zvm_previous_address(const zvm_t *vm);

zvm_error_t zvm_read_byte(const zvm_t *vm, uint32_t address, uint8_t *out);
zvm_error_t zvm_read_word(const zvm_t *vm, uint32_t address, uint16_t *out);
zvm_error_t zvm_write_byte(zvm_t *vm, uint32_t address, uint8_t value);
zvm_error_t zvm_stack_push(zvm_t *vm, uint16_t value);
zvm_error_t zvm_stack_pop(zvm_t *vm, uint16_t *value);
zvm_error_t zvm_global(const zvm_t *vm, uint8_t index, uint16_t *value);
zvm_error_t zvm_object_links(const zvm_t *vm, uint8_t object,
			     uint8_t *parent, uint8_t *sibling, uint8_t *child);
zvm_error_t zvm_object_attribute(const zvm_t *vm, uint8_t object,
				 uint8_t attribute, uint8_t *set);
/* Copies property bytes to host storage; never returns a story-memory pointer. */
zvm_error_t zvm_object_property(const zvm_t *vm, uint8_t object,
				uint8_t property, uint8_t *out,
				uint8_t capacity, uint8_t *length);
/* Game-specific convention: Zork I global 0 (variable 16) stores the room. */
zvm_error_t zvm_zork_room(const zvm_t *vm, uint16_t *room);

#endif
